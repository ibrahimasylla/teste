using System;

public class Robot
{
    public string Nom
    {
        get
        {
            throw new NotImplementedException("Vous devez implémenter cette propriété.");
        }
    }

    public void Reinitialiser()
    {
        throw new NotImplementedException("Vous devez implémenter cette méthode.");
    }
}