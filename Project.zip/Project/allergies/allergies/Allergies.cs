using System;

public enum Allergene
{
    Oeufs,
    Arachides,
    Crustaces,
    Fraises,
    Tomates,
    Chocolat,
    Pollen,
    Chats
}

public class Allergies
{
    public Allergies(int mask)
    {
    }

    public bool EstAllergique(Allergene allergen)
    {
        throw new NotImplementedException("Vous devez implémenter cette fonction.");
    }

    public Allergene[] Liste()
    {
        throw new NotImplementedException("Vous devez implémenter cette fonction.");
    }
}