using System;

public static class CombinaisonsUnitesLexicales
{
    public static bool Valide(string code)
    {
        throw new NotImplementedException();
    }
}
