# Gestion des exceptions

Implémentez différents types de gestion des erreurs et de gestion des ressources.

Un des principes importants de la programmation est de savoir comment gérer les erreurs et la libération des ressources allouées même si des erreurs se produisent.

## Exécution des tests

Pour exécuter les tests, exécutez la commande `dotnet test` à partir du répertoire de l'exercice.

Initialement, seul le premier test sera activé. C'est pour vous encourager à résoudre l'exercice une étape à la fois.
Une fois que vous avez réussi le premier test, supprimez la propriété `Skip` du test suivant et travaillez à faire passer ce prochain test.
Une fois qu'aucun des tests n'est ignoré et qu'ils réussissent tous, vous devez soumettre votre solution.
