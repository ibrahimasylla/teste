﻿using System;

public static class GestionDesExceptions
{
    public static void Gerer_l_erreur_en_lancant_une_exception()
    {
        throw new NotImplementedException("Vous devez implémenter cette fonction.");
    }

    public static int? Gerer_l_erreur_en_retournant_un_type_Nullable(string input)
    {
        throw new NotImplementedException("Vous devez implémenter cette fonction.");
    }

    public static bool Gerer_l_erreur_en_avec_un_parametre_out(string input, out int result)
    {
        throw new NotImplementedException("Vous devez implémenter cette fonction.");
    }

    public static void Les_ressources_non_gerees_sont_liberer_lorsqu_une_exception_est_lancee(IDisposable disposableObject)
    {
        throw new NotImplementedException("Vous devez implémenter cette fonction.");
    }
}
