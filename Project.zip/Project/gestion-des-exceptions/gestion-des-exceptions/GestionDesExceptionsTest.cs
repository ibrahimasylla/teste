﻿using System;
using Xunit;

public class GestionDesExceptionsTest
{
    // https://docs.microsoft.com/fr-ca/dotnet/csharp/programming-guide/exceptions/exception-handling
    [Fact]
    public void Gerer_l_erreur_en_lancant_une_exception()
    {
        Assert.Throws<Exception>(() => GestionDesExceptions.Gerer_l_erreur_en_lancant_une_exception());
    }

    // https://docs.microsoft.com/fr-ca/dotnet/csharp/language-reference/builtin-types/nullable-value-types
    [Fact(Skip = "Supprimer pour exécuter le test")]
    public void Gerer_l_erreur_en_retournant_un_type_Nullable()
    {
        var resultatReussi = GestionDesExceptions.Gerer_l_erreur_en_retournant_un_type_Nullable("1");
        Assert.Equal(1, resultatReussi);

        var resultatEchec = GestionDesExceptions.Gerer_l_erreur_en_retournant_un_type_Nullable("a");
        Assert.Null(resultatEchec);
    }

    // https://docs.microsoft.com/fr-ca/dotnet/csharp/language-reference/keywords/out
    [Fact(Skip = "Supprimer pour exécuter le test")]
    public void Gerer_l_erreur_en_avec_un_parametre_out()
    {
        int result;
        var resultatReussi = GestionDesExceptions.Gerer_l_erreur_en_avec_un_parametre_out("1", out result);
        Assert.True(resultatReussi);
        Assert.Equal(1, result);
        
        var resultatEchec = GestionDesExceptions.Gerer_l_erreur_en_avec_un_parametre_out("a", out result);
        Assert.False(resultatEchec);
    }

    private class DisposableResource : IDisposable
    {
        public bool IsDisposed { get; private set; }

        public void Dispose()
        {
            IsDisposed = true;
        }
    }

    // https://docs.microsoft.com/fr-ca/dotnet/api/system.idisposable
    [Fact(Skip = "Supprimer pour exécuter le test")]
    public void Les_ressources_non_gerees_sont_liberer_lorsqu_une_exception_est_lancee()
    {
        var disposableResource = new DisposableResource();

        Assert.Throws<Exception>(() => GestionDesExceptions.Les_ressources_non_gerees_sont_liberer_lorsqu_une_exception_est_lancee(disposableResource));
        Assert.True(disposableResource.IsDisposed);
    }
}
