using System;

public static class ChiffrementParDecalage
{
    public static string Decaler(string texte, int cleDeChiffrement)
    {
        throw new NotImplementedException("Vous devez implémenter cette fonction.");
    }
}
